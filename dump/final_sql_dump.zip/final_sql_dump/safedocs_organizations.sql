-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: safedocs
-- ------------------------------------------------------
-- Server version	8.0.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `OrganizationID` bigint NOT NULL,
  `OrgName` text NOT NULL,
  `OrgType` text,
  `Address` text,
  `CreatedAt` datetime NOT NULL,
  PRIMARY KEY (`OrganizationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,'Rodriguez, Rubio and Morton','Tech','05833 Desiree Walk, Port John, NC 69855','2023-09-21 15:33:44'),(2,'Nelson, Hughes and Patel','Finance','PSC 8164, Box 6113, APO AE 31959','2024-10-06 10:50:55'),(3,'Cruz-Bryant','Tech','8948 Tamara Locks Apt. 114, North Whitneyside, AK 74879','2018-03-12 16:13:54'),(4,'Dominguez, Clark and Young','Legal','9445 John Fork Apt. 391, Justinbury, IL 23105','2011-11-17 17:06:31'),(5,'Green and Sons','Finance','259 Holly Junctions, South Jacob, MN 02135','2012-02-28 05:32:48'),(6,'Campbell and Sons','Finance','31765 Olivia Summit Suite 438, South Denise, MT 82359','2019-04-24 04:35:18'),(7,'Carr-Schmitt','Tech','730 Kevin Stravenue, Lorimouth, FL 24693','2021-10-24 21:45:34'),(8,'Johnson, Hays and Quinn','Finance','USNS Larson, FPO AE 54198','2013-09-06 02:06:46'),(9,'Hunter Inc','Legal','8240 Cristian Greens Apt. 044, Johnsonton, AZ 56900','2006-06-24 13:21:24'),(10,'Anderson-Huang','Academic','Unit 2594 Box 3428, DPO AE 25708','2024-12-20 13:55:35'),(11,'Watts-Thomas','Academic','0764 Deborah Forks Apt. 966, Port Angelaberg, MH 59247','2019-07-05 23:02:50'),(12,'Chase, Gordon and Garcia','Tech','7449 Lisa Neck Suite 904, West Patriciashire, GA 43029','2015-08-29 00:12:41'),(13,'Warner, Gallegos and Blair','Tech','8446 Jennifer Lakes, Craigside, AZ 84546','2024-09-08 12:26:48'),(14,'Cooper, Meyer and Tran','Tech','66048 Timothy Center Suite 609, Smallville, NY 29194','2019-09-30 17:27:09'),(15,'Walker LLC','Academic','275 Regina Cove, Carterport, MS 57433','2011-01-29 07:04:44'),(16,'Johnson and Sons','Finance','437 Stewart Corners Suite 871, Williamstad, VI 20857','2008-11-24 05:53:52'),(17,'Ford Group','Legal','2269 Harmon Spurs, Josephmouth, SC 07846','2010-08-22 04:31:11'),(18,'Diaz Ltd','Legal','02029 Nelson Causeway Apt. 709, North Mercedesmouth, WY 97854','2010-11-13 12:14:16'),(19,'Compton Ltd','Tech','729 Sullivan Key Apt. 351, Lake Cynthiaville, MO 21225','2012-06-22 01:29:42'),(20,'Carpenter PLC','Legal','57148 Susan Heights, West Troy, DE 28967','2008-12-28 09:30:46');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-15 17:46:59
